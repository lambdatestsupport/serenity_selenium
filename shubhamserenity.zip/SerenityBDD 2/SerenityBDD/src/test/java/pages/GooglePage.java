package pages;


import net.serenitybdd.core.pages.PageObject;

public class GooglePage extends PageObject {

}
